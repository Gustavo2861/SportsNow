# SportsNow
Plataforma digital que tem o objetivo de facilitar o encontro e fomação de times para praticas esportivas.
## Equipe SportsNow
- Alyson Silva [@alisaoff](https://github.com/alisaoff)
- Andreia Mayumi [@AndreiaMayumi](https://github.com/AndreiaMayumi)
- Diogo Spinelli da Silva [@DiogoSpinelli20](https://github.com/DiogoSpinelli20) 
- Gustavo Pereira Andrade [@Gustavo2861](https://github.com/Gustavo2861)
- Ingrid Sepulvida [@Ingridsepulvida](https://github.com/Ingridsepulvida)


## TAREFAS

### Telas
- Principal
- Login
- Cadastro
- Perfil
- Interclasse
- Oficial
- Peladas
- Calendário
- Criação de Times
- Gerenciamento de Times
- Sobre
- Termos e Condições
